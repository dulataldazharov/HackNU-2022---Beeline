import pandas as pd
from contextlib import redirect_stdout
import json

from parse_idxs import find_identifiers
from dfs import DAG, get_leaf_to_filename

# Spark Explain Output Related variables
EXPLAIN_FILE_NAME = 'out.txt'
FINAL_COLUMNS_HEAD = "AdaptiveSparkPlan"
explain_plan_content = []
final_ids = []

# Dependency clauses to parse
AS_CLAUSE = " AS "
FILTERING_CLAUSES = ["Filter", "Join"]

# Graph-related variables
adj_map = {}
filtering_dependencies = []


def initialize_explain_plans():
    # with open(EXPLAIN_FILE_NAME, 'w') as file:
    #     with redirect_stdout(file):
    #         data_frame.explain(True)
    #     file.close()
    with open(EXPLAIN_FILE_NAME, 'r') as file:
        is_final_columns_line = False
        for line in file:
            explain_plan_content.append(line)
            if is_final_columns_line:
                final_ids += find_identifiers(line)
                is_final_columns_line = False
            if FINAL_COLUMNS_HEAD in line:
                is_final_columns_line = True
        file.close()

def add_as_clause_dependency(line: str):
    for i in range(0, len(line)-3):
        if line[i:i+4] == AS_CLAUSE:
            parent_name = find_identifiers(line[i:], True)
            if parent_name is None:
                continue
            left = i
            bracket_depth = 0
            if (parent_name == "LAST_SERIAL_NUM_MONTHLY#1384"):
                print(parent_name)
            while not(left < 1 or (bracket_depth == 0 and line[left] in [',', '['])):
                if line[left] == ')':
                    bracket_depth += 1
                elif line[left] == '(':
                    bracket_depth -= 1
                left -= 1
            child_names = find_identifiers(line[left:i])
            if parent_name not in adj_map:
                adj_map[parent_name] = []
            for child in child_names:
                adj_map[parent_name].append(child)

def add_dependencies():
    for line in explain_plan_content:
        add_as_clause_dependency(line)
        add_filtering_dependencies(line)

def add_filtering_dependencies(line: str):
    for filter_clause in FILTERING_CLAUSES:
        if filter_clause in line:
            identifiers = find_identifiers(line)
            for id in identifiers:
                filtering_dependencies.append(id)



initialize_explain_plans()
add_dependencies()
filtering_dependencies = list(set(filtering_dependencies))

dag = DAG(adj_map)

final_id_to_deps = dict()
for id in final_ids:
    final_id_to_deps[id] = dag.get_deps(id)

leaf_to_filename = get_leaf_to_filename(explain_plan_content)

common_leaf_deps = set()
for id in filtering_dependencies:
    for leaf in dag.get_deps(id):
        common_leaf_deps.add(leaf)

result = dict()
for id, deps in final_id_to_deps.items():
    col_names = set()
    source_names = set()
    for dep in set(deps) | common_leaf_deps:
        if dep not in leaf_to_filename:
            continue
        
        source_name = leaf_to_filename[dep]
        col_name = dep.split('#')[0]
        col_names.add(f"{source_name[:-4]}.{col_name}")
        source_names.add(source_name)

    result[id.split('#')[0]] = {
        "data_sources": list(source_names),
        "cols_dependencies": list(col_names),
    }

print(json.dumps(result, indent=4))