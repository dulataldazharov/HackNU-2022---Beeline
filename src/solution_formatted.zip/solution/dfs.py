from parse_idxs import find_identifiers


class DAG:
    def __init__(self, node_to_neighbors):
        self._g = node_to_neighbors
        self._cache = dict()

    def get_deps(self, node):
        if node in self._cache:
            return self._cache[node]
        
        deps = set()
        for to in self._g.get(node, []):
            for to_dep in self.get_deps(to):
                deps.add(to_dep)

        if not self._g.get(node, []):
            deps.add(node)

        self._cache[node] = list(deps)
        return self._cache[node]


def get_leaf_to_filename(plan_content):
    node_to_filename = dict()
    
    for line in plan_content:
        if line.find("InMemoryFileIndex") == -1:
            continue
        
        r = line.find(".csv")
        l = r - 1
        r = r + 4
        
        while line[l] != '/':
            l = l - 1

        filename = line[l + 1:r]
        for id in find_identifiers(line):
            node_to_filename[id] = filename

    return node_to_filename
